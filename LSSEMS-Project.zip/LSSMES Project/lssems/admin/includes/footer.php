<footer class="main-footer">
    Local Service Serach Engine.
    
  </footer>